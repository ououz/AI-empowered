// src/routes/profile.js
const express = require("express");
const Profile = require("../models/Profile");
const auth = require("../middleware/auth");

const router = express.Router();

// 获取我的个人资料
router.get("/me", auth, async (req, res) => {
    let profile = await Profile.findOne({ userId: req.user.id });
    if (!profile) profile = await Profile.create({ userId: req.user.id });
    res.json(profile);
});

// 更新我的个人资料
router.put("/me", auth, async (req, res) => {
    const data = req.body; // {realName, skills, education, experience, contact, bio, avatar...}
    const profile = await Profile.findOneAndUpdate(
        { userId: req.user.id },
        { $set: data },
        { new: true, upsert: true }
    );
    res.json(profile);
});

module.exports = router;
